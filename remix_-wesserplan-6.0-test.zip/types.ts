
export type TabName = 'dashboard' | 'communes' | 'mairie' | 'wplan' | 'define-areas' | 'operations' | 'upload' | 'settings';

export type Organization = 'msf' | 'unicef' | 'wwf' | 'mdm';

export type CommuneStatus = 'pas_demande' | 'informe' | 'refuse' | 'telescope' | 'fait';

export interface Commune {
  id: number;
  nom: string;
  departement: string;
  population: number;
  passage: string;
  statut: CommuneStatus;
  maire: string;
  revenue: string;
  lat: number;
  lng: number;
  // New fields for contact and history
  email?: string;
  phone?: string;
  historiquePassages?: Record<string, string[]>;
}

export interface DepartmentMap {
  [key: string]: string;
}

export interface StatusMap {
  [key: string]: { text: string; color: string; bg: string };
}

// --- New types for DefineAreasTab ---
export interface HistoricalData {
  lastPassage?: string; // YYYY-MM-DD
}

export interface AreaCommune {
  name: string;
  code: string;
  pop: number;
  lat: number;
  lng: number;
  history: HistoricalData;
}

export interface GeneratedZone {
  id: string; // e.g., "week-12-zone-1"
  weekNumber: number;
  teamId: number;
  communes: AreaCommune[];
  pop: number;
  color: string; // Based on history
  names: string;
  // Layer reference for map interactions
  layer?: any; 
  tooltipContent: string;
}

export const HISTORY_COLORS: Record<string, {label: string, color: string}> = {
  next_week: { label: "Semaine prochaine", color: '#be185d' }, // Pink
  current_week: { label: "Semaine actuelle", color: '#4f46e5' }, // Indigo
  previous_week: { label: "Semaine précédente", color: '#2563eb' }, // Blue
  two_weeks_ago: { label: "Il y a 2 semaines", color: '#0891b2' }, // Cyan
  under_2_months: { label: "Moins de 2 mois", color: '#059669' }, // Emerald
  under_4_months: { label: "Moins de 4 mois", color: '#65a30d' }, // Lime
  under_6_months: { label: "Moins de 6 mois", color: '#f59e0b' }, // Amber
  under_1_year: { label: "Moins de 1 an", color: '#e11d48' }, // Rose
  never: { label: "Jamais faites", color: '#6b7280' }, // Gray
};

export interface PopulationThresholds {
  zone1: number; // 7000
  zone1_max: number; // 9000
  zone2: number; // 16000
  zone3: number; // 32000
  exclude: number; // 70000
}
