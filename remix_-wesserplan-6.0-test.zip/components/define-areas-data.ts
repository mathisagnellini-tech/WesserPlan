import { AreaCommune } from '../types';

// Données de secours pour l'Alsace si l'API ne répond pas
export const communes: AreaCommune[] = [
  { name: "Strasbourg", code: "67482", pop: 291313, lat: 48.5734, lng: 7.7521, history: {} },
  { name: "Haguenau", code: "67180", pop: 35715, lat: 48.8162, lng: 7.7878, history: {} },
  { name: "Schiltigheim", code: "67447", pop: 34129, lat: 48.6085, lng: 7.7494, history: {} },
  { name: "Illkirch-Graffenstaden", code: "67218", pop: 27118, lat: 48.5285, lng: 7.7110, history: {} },
  { name: "Sélestat", code: "67462", pop: 19252, lat: 48.2595, lng: 7.4542, history: {} },
  { name: "Lingolsheim", code: "67267", pop: 20266, lat: 48.5539, lng: 7.6856, history: {} },
  { name: "Bischheim", code: "67043", pop: 17939, lat: 48.6163, lng: 7.7529, history: {} },
  { name: "Colmar", code: "68066", pop: 67730, lat: 48.0794, lng: 7.3585, history: {} },
  { name: "Mulhouse", code: "68224", pop: 106315, lat: 47.7508, lng: 7.3359, history: {} },
  { name: "Saint-Louis", code: "68297", pop: 22835, lat: 47.5857, lng: 7.5619, history: {} },
  { name: "Illzach", code: "68154", pop: 14380, lat: 47.7823, lng: 7.3467, history: {} },
  { name: "Wittenheim", code: "68376", pop: 15264, lat: 47.8078, lng: 7.3376, history: {} },
  { name: "Rixheim", code: "68278", pop: 14204, lat: 47.7515, lng: 7.3973, history: {} },
  { name: "Kingersheim", code: "68166", pop: 13178, lat: 47.7919, lng: 7.3391, history: {} },
  { name: "Riedisheim", code: "68271", pop: 12161, lat: 47.7491, lng: 7.3690, history: {} },
  { name: "Guebwiller", code: "68112", pop: 11137, lat: 47.9077, lng: 7.2137, history: {} },
  { name: "Cernay", code: "68063", pop: 11745, lat: 47.8097, lng: 7.1775, history: {} },
  { name: "Wittelsheim", code: "68375", pop: 10334, lat: 47.7959, lng: 7.2390, history: {} }
];