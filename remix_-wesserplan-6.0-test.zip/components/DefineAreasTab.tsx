
import React, { useEffect, useRef, useState, useMemo } from 'react';
import { GeneratedZone, PopulationThresholds, Organization } from '../types';
import { Settings, RefreshCw, MapPin, Users, CheckCircle2, Layers, Calendar, Eye, Filter, ChevronDown, Search, X } from 'lucide-react';

declare const L: any;

// --- UTILS ---
const Tooltip: React.FC<{ info: { x: number, y: number, content: string } | null }> = ({ info }) => {
    if (!info) return null;
    return (
        <div
            className="tooltip-zone"
            style={{ left: info.x, top: info.y, display: info.content ? 'block' : 'none' }}
            dangerouslySetInnerHTML={{ __html: info.content }}
        />
    );
};

const inputClasses = "w-full bg-white border border-gray-200 text-slate-700 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 transition shadow-sm";

// --- CONSTANTS ---
const API_GEO_URL = 'https://geo.api.gouv.fr/departements';

const DEPARTMENTS = [
    { code: '06', label: 'Alpes-Maritimes' },
    { code: '11', label: 'Aude' },
    { code: '13', label: 'Bouches-du-Rhône' },
    { code: '17', label: 'Charente-Maritime' },
    { code: '22', label: "Côtes-d'Armor" },
    { code: '29', label: 'Finistère' },
    { code: '30', label: 'Gard' },
    { code: '67', label: 'Bas-Rhin' },
    { code: '68', label: 'Haut-Rhin' },
    { code: '73', label: 'Savoie' },
    { code: '74', label: 'Haute-Savoie' },
    { code: '75', label: 'Paris' },
    { code: '76', label: 'Seine-Maritime' },
    { code: '77', label: 'Seine-et-Marne' },
    { code: '78', label: 'Yvelines' },
    { code: '79', label: 'Deux-Sèvres' },
    { code: '83', label: 'Var' },
    { code: '84', label: 'Vaucluse' },
    { code: '91', label: 'Essonne' },
    { code: '92', label: 'Hauts-de-Seine' },
    { code: '93', label: 'Seine-Saint-Denis' },
    { code: '94', label: 'Val-de-Marne' },
    { code: '95', label: "Val-d'Oise" },
];

const ORGS_CONFIG: Record<Organization, { color: string, label: string }> = {
    'msf': { color: '#ef4444', label: 'MSF' },
    'unicef': { color: '#3b82f6', label: 'UNICEF' },
    'wwf': { color: '#10b981', label: 'WWF' },
    'mdm': { color: '#6366f1', label: 'MDM' }
};

const DefineAreasTab: React.FC<{ isActive: boolean }> = ({ isActive }) => {
    const mapContainerRef = useRef<HTMLDivElement>(null);
    const mapInstanceRef = useRef<any | null>(null);
    const geoJsonLayerRef = useRef<any | null>(null);

    // UI State
    const [isLoading, setIsLoading] = useState(true);
    const [isGenerating, setIsGenerating] = useState(false);
    const [generationStatus, setGenerationStatus] = useState<string>("");
    const [selectedOrg, setSelectedOrg] = useState<Organization>('msf');
    const [viewWeek, setViewWeek] = useState<number | 'all'>('all');
    
    // Config State
    const [selectedDepts, setSelectedDepts] = useState<string[]>(['67', '68', '76']);
    const [isDeptDropdownOpen, setIsDeptDropdownOpen] = useState(false);
    const [deptSearch, setDeptSearch] = useState('');

    const [targetPopulation, setTargetPopulation] = useState<number>(8000); // Cible demandée
    const [weeklyTeams, setWeeklyTeams] = useState<number[]>(Array(52).fill(2));
    const [seedCommuneName, setSeedCommuneName] = useState('Strasbourg');
    const [maxCommunePop, setMaxCommunePop] = useState(70000); // Exclude big cities
    
    // Data State (Stored after generation)
    const [generatedZones, setGeneratedZones] = useState<any[]>([]);
    const [rawFeatures, setRawFeatures] = useState<any[]>([]); // To keep cached geojson

    // Stats
    const [stats, setStats] = useState({ zones: 0, communes: 0, pop: 0 });
    const [tooltipInfo, setTooltipInfo] = useState<{ x: number, y: number, content: string } | null>(null);

    // --- MAP INITIALIZATION ---
    useEffect(() => {
        setRawFeatures([]); // Clear cache when depts change
    }, [selectedDepts]);

    useEffect(() => {
        if (mapContainerRef.current && !mapInstanceRef.current) {
            const map = L.map(mapContainerRef.current, { zoomControl: false }).setView([48.3, 7.5], 9); // Centré Alsace
            L.tileLayer.provider('CartoDB.Positron').addTo(map);
            L.control.zoom({ position: 'topright' }).addTo(map);
            mapInstanceRef.current = map;
            setIsLoading(false);
        }
    }, []);

    useEffect(() => { 
        if (isActive && mapInstanceRef.current) { 
            setTimeout(() => mapInstanceRef.current.invalidateSize(), 150); 
        } 
    }, [isActive]);

    // --- ALGORITHM UTILS ---
    const getDistance = (lat1: number, lng1: number, lat2: number, lng2: number) => {
        const R = 6371; 
        const dLat = (lat2 - lat1) * (Math.PI / 180);
        const dLon = (lng2 - lng1) * (Math.PI / 180);
        const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
            Math.cos(lat1 * (Math.PI / 180)) * Math.cos(lat2 * (Math.PI / 180)) *
            Math.sin(dLon / 2) * Math.sin(dLon / 2);
        const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        return R * c; 
    };

    // --- GENERATION LOGIC (REAL GEOJSON + STRICT NEIGHBORHOOD) ---
    const handleGenerateZones = async () => {
        if (!mapInstanceRef.current) return;
        
        if (selectedDepts.length === 0) {
            alert("Veuillez sélectionner au moins un département.");
            return;
        }

        setIsGenerating(true);
        setGenerationStatus("Récupération des données officielles (API Gouv)...");

        try {
            let features = rawFeatures;

            // 1. Fetch GeoJSON for selected depts only if not cached
            if (features.length === 0) {
                const fetchedFeatures: any[] = [];
                for (const dept of selectedDepts) {
                    const response = await fetch(`${API_GEO_URL}/${dept}/communes?geometry=contour&format=geojson&type=commune-actuelle`);
                    const data = await response.json();
                    fetchedFeatures.push(...data.features);
                }
                
                // Pre-process centroids
                features = fetchedFeatures.map(f => {
                    const coords = f.geometry.coordinates[0]; 
                    const ring = (coords.length > 1 && Array.isArray(coords[0])) ? coords[0] : coords; 
                    let minX = Infinity, maxX = -Infinity, minY = Infinity, maxY = -Infinity;
                    ring.forEach((p: any) => {
                        const lng = Array.isArray(p) ? p[0] : 0;
                        const lat = Array.isArray(p) ? p[1] : 0;
                        minX = Math.min(minX, lng);
                        maxX = Math.max(maxX, lng);
                        minY = Math.min(minY, lat);
                        maxY = Math.max(maxY, lat);
                    });

                    return {
                        ...f,
                        properties: {
                            ...f.properties,
                            lat: (minY + maxY) / 2,
                            lng: (minX + maxX) / 2,
                            assigned: false
                        }
                    };
                });
                setRawFeatures(features);
            } else {
                // Reset assignment if re-generating
                features.forEach(f => f.properties.assigned = false);
            }

            setGenerationStatus(`Traitement de ${features.length} communes...`);

            // 2. Find Seed
            let startCommune = features.find(f => f.properties.nom.toLowerCase() === seedCommuneName.toLowerCase());
            if (!startCommune) startCommune = features[0]; // Fallback

            // 3. Global Clustering Algorithm (Strict Nearest Neighbor)
            setGenerationStatus("Calcul des zones compactes...");
            
            const territories: any[] = [];
            
            // Filter out massive cities if requested
            const availableFeatures = features.filter(f => f.properties.population <= maxCommunePop);
            let remainingCommunesCount = availableFeatures.length;
            
            let currentSeed = startCommune && startCommune.properties.population <= maxCommunePop ? startCommune : availableFeatures[0];

            // SAFETY BREAK to prevent infinite loops
            let loopCount = 0;
            const MAX_LOOPS = 5000; 

            while (remainingCommunesCount > 0 && loopCount < MAX_LOOPS) {
                loopCount++;
                
                if (!currentSeed || currentSeed.properties.assigned) {
                    // Find next seed: Strictly the closest available commune to the LAST created zone
                    // This ensures we don't jump across the map
                    let bestNextSeed = null;
                    let minDistToLastZone = Infinity;

                    const searchPool = availableFeatures.filter(f => !f.properties.assigned);
                    const lastTerritory = territories.length > 0 ? territories[territories.length - 1] : null;
                    
                    if (lastTerritory && searchPool.length > 0) {
                        // Check every unassigned commune against every commune in the last territory
                        // This is expensive but ensures continuity
                        // Optimization: Just check distance to last territory centroid first, then refine if needed?
                        // Better: Just check closest to ANY member of last zone.
                        
                        // To keep it fast enough for JS:
                        // Calculate distance to last territory's centroid first
                        for (const cand of searchPool) {
                            const d = getDistance(lastTerritory.lat, lastTerritory.lng, cand.properties.lat, cand.properties.lng);
                            if (d < minDistToLastZone) {
                                minDistToLastZone = d;
                                bestNextSeed = cand;
                            }
                        }
                    } else if (searchPool.length > 0) {
                         // Start new disconnected cluster (should rarely happen if map is contiguous)
                         bestNextSeed = searchPool[0];
                    }
                    
                    currentSeed = bestNextSeed;
                    if (!currentSeed) break; // Done
                }

                // Create a new Territory
                const territory = {
                    communes: [currentSeed],
                    pop: currentSeed.properties.population,
                    lat: currentSeed.properties.lat,
                    lng: currentSeed.properties.lng
                };
                currentSeed.properties.assigned = true;
                remainingCommunesCount--;

                // Grow Territory until ~Target Population using STRICT ADJACENCY
                let growing = true;
                while (growing && territory.pop < targetPopulation * 1.15) { // Allow 15% overflow
                    
                    let bestNeighbor = null;
                    let minDistToZone = Infinity;
                    
                    const searchPool = availableFeatures.filter(f => !f.properties.assigned);

                    for (const candidate of searchPool) {
                        // Optimization: rough box check against territory centroid
                        if (Math.abs(candidate.properties.lat - territory.lat) > 0.1) continue;

                        // Find minimum distance from this candidate to ANY commune in the current zone
                        // This simulates "touching" borders
                        for (const member of territory.communes) {
                            const d = getDistance(member.properties.lat, member.properties.lng, candidate.properties.lat, candidate.properties.lng);
                            if (d < minDistToZone) {
                                minDistToZone = d;
                                bestNeighbor = candidate;
                            }
                        }
                    }

                    // If we found a neighbor (we always should if list not empty and not islands)
                    // And adding it doesn't grossly exceed target (unless zone is emptyish)
                    if (bestNeighbor) {
                         if (territory.pop < targetPopulation * 0.6 || (territory.pop + bestNeighbor.properties.population < targetPopulation * 1.3)) {
                            territory.communes.push(bestNeighbor);
                            territory.pop += bestNeighbor.properties.population;
                            bestNeighbor.properties.assigned = true;
                            remainingCommunesCount--;
                            
                            // Update centroid
                            let sumLat = 0, sumLng = 0;
                            territory.communes.forEach((c:any) => { sumLat += c.properties.lat; sumLng += c.properties.lng; });
                            territory.lat = sumLat / territory.communes.length;
                            territory.lng = sumLng / territory.communes.length;

                            // If just adding this one pushed us way over, we accept it but stop growing
                            if (territory.pop >= targetPopulation) growing = false;

                    } else {
                        growing = false; // No neighbors found (isolated)
                    }
                } else {
                    growing = false; // No neighbors found
                }
            }
            
            territories.push(territory);
            currentSeed = null; // Trigger find next seed
        }

        // 4. Dispatch Territories into Weeks/Teams
        setGenerationStatus("Planification S1-S52...");
        
        const finalZones: any[] = [];
        let territoryIndex = 0;

        for (let week = 1; week <= 52; week++) {
            const teamsCount = weeklyTeams[week - 1];
            if (teamsCount === 0) continue;

            for (let teamId = 0; teamId < teamsCount; teamId++) {
                if (territoryIndex >= territories.length) break;

                const t = territories[territoryIndex];
                
                finalZones.push({
                    ...t,
                    week,
                    teamId,
                    id: `W${week}-T${teamId}`
                });
                territoryIndex++;
            }
        }

        setGeneratedZones(finalZones);
        
        // Stats Update
        const totalPop = finalZones.reduce((acc, z) => acc + z.pop, 0);
        setStats({ zones: finalZones.length, communes: features.length, pop: totalPop });

    } catch (err) {
        console.error("Erreur génération", err);
        alert("Erreur lors de la récupération des données GeoJSON ou du calcul.");
    } finally {
        setIsGenerating(false);
        setGenerationStatus("");
    }
};

    // --- MAP LAYER UPDATE ---
    useEffect(() => {
        if (!mapInstanceRef.current) return;

        // Clear layers
        if (geoJsonLayerRef.current) {
            mapInstanceRef.current.removeLayer(geoJsonLayerRef.current);
        }

        if (generatedZones.length === 0) return;

        // Filter based on View
        const zonesToDisplay = viewWeek === 'all' 
            ? generatedZones 
            : generatedZones.filter(z => z.week === viewWeek);

        if (zonesToDisplay.length === 0) return;

        // Flatten for GeoJSON
        const displayFeatures: any[] = [];
        
        zonesToDisplay.forEach(zone => {
            zone.communes.forEach((c: any) => {
                displayFeatures.push({
                    type: "Feature",
                    geometry: c.geometry,
                    properties: {
                        ...c.properties,
                        zoneWeek: zone.week,
                        zoneTeam: zone.teamId,
                        zonePop: zone.pop
                    }
                });
            });
        });

        // Week Colors Palette
        const weekColors = [
            '#ef4444', '#f97316', '#f59e0b', '#84cc16', '#10b981', 
            '#06b6d4', '#3b82f6', '#6366f1', '#8b5cf6', '#d946ef', '#f43f5e'
        ];

        const layer = L.geoJSON({ type: "FeatureCollection", features: displayFeatures }, {
            style: (feature: any) => {
                const week = feature.properties.zoneWeek;
                const color = viewWeek === 'all' 
                    ? weekColors[(week - 1) % weekColors.length]
                    : ['#2563eb', '#dc2626', '#16a34a', '#ca8a04'][feature.properties.zoneTeam % 4];

                return {
                    fillColor: color,
                    weight: 0.5,
                    opacity: 1,
                    color: 'white',
                    dashArray: '',
                    fillOpacity: 0.75
                };
            },
            onEachFeature: (feature: any, layer: any) => {
                    layer.bindTooltip(
                    `<div class="font-sans text-center">
                        <b>${feature.properties.nom}</b><br/>
                        <span class="text-xs text-slate-500">${feature.properties.population} hab.</span><br/>
                        <span class="text-xs font-bold text-blue-600">Semaine ${feature.properties.zoneWeek}</span>
                    </div>`,
                    { sticky: true, direction: 'top' }
                );
                layer.on('mouseover', (e: any) => {
                    setTooltipInfo({
                        x: e.originalEvent.clientX,
                        y: e.originalEvent.clientY,
                        content: `<b>${feature.properties.nom}</b><br/>Semaine ${feature.properties.zoneWeek}<br/>${feature.properties.population.toLocaleString()} hab.`
                    });
                });
                layer.on('mouseout', () => setTooltipInfo(null));
            }
        }).addTo(mapInstanceRef.current);

        geoJsonLayerRef.current = layer;
        
        if (zonesToDisplay.length > 0 && viewWeek !== 'all') {
             mapInstanceRef.current.fitBounds(layer.getBounds());
        } else if (generatedZones.length > 0 && !isGenerating) {
             mapInstanceRef.current.fitBounds(layer.getBounds());
        }

    }, [generatedZones, viewWeek, isGenerating]);


    const handleBulkTeams = (val: number) => {
        setWeeklyTeams(Array(52).fill(val));
    };

    const handleWeeklyTeamChange = (idx: number, val: number) => {
        const n = [...weeklyTeams];
        n[idx] = val;
        setWeeklyTeams(n);
    };

    return (
        <section className="h-[calc(100vh_-_90px)] flex gap-6">
            <Tooltip info={tooltipInfo} />
            
            {/* LEFT: CONFIGURATION & TEAMS */}
            <div className="w-[400px] flex flex-col gap-4 flex-shrink-0 h-full overflow-hidden">
                
                {/* 1. Setup Panel */}
                <div className="glass-card p-5 flex-shrink-0 relative z-20">
                    <h2 className="text-3xl font-extrabold text-slate-900 mb-4 flex items-center gap-2 tracking-tight">
                        <Settings className="text-blue-600" /> Zonage Stratégique
                    </h2>
                    
                    <div className="space-y-4">
                         <div className="relative z-50">
                             <label className="text-xs font-bold text-slate-500 uppercase mb-1 block">Départements</label>
                             <button 
                                 onClick={() => setIsDeptDropdownOpen(!isDeptDropdownOpen)}
                                 className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2.5 text-left flex items-center justify-between shadow-sm hover:border-blue-300 transition-colors"
                             >
                                 <span className="text-sm font-bold text-slate-700 truncate">
                                     {selectedDepts.length === 0 
                                         ? 'Sélectionner...' 
                                         : `${selectedDepts.length} département(s)`}
                                 </span>
                                 <ChevronDown size={16} className="text-slate-400"/>
                             </button>

                             {isDeptDropdownOpen && (
                                 <div className="absolute top-full left-0 w-full mt-2 bg-white border border-slate-100 rounded-xl shadow-xl overflow-hidden animate-fade-in">
                                     <div className="p-2 border-b border-slate-50">
                                         <div className="relative">
                                             <Search size={14} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400"/>
                                             <input 
                                                 type="text" 
                                                 placeholder="Chercher..." 
                                                 className="w-full bg-slate-50 border border-slate-100 rounded-lg pl-8 pr-2 py-1.5 text-xs font-medium focus:outline-none focus:ring-2 focus:ring-blue-100"
                                                 value={deptSearch}
                                                 onChange={(e) => setDeptSearch(e.target.value)}
                                                 autoFocus
                                             />
                                         </div>
                                     </div>
                                     <div className="max-h-48 overflow-y-auto custom-scrollbar p-1">
                                         {DEPARTMENTS.filter(d => d.label.toLowerCase().includes(deptSearch.toLowerCase()) || d.code.includes(deptSearch)).map(dept => (
                                             <label key={dept.code} className="flex items-center gap-3 p-2 hover:bg-slate-50 rounded-lg cursor-pointer group transition-colors">
                                                 <div className={`w-4 h-4 rounded border flex items-center justify-center transition-colors ${selectedDepts.includes(dept.code) ? 'bg-blue-600 border-blue-600' : 'border-slate-300 bg-white'}`}>
                                                     {selectedDepts.includes(dept.code) && <CheckCircle2 size={10} className="text-white" />}
                                                 </div>
                                                 <span className="text-xs font-bold text-slate-600 group-hover:text-slate-900">
                                                     {dept.code} - {dept.label}
                                                 </span>
                                                 <input 
                                                     type="checkbox" 
                                                     className="hidden"
                                                     checked={selectedDepts.includes(dept.code)}
                                                     onChange={() => {
                                                         setSelectedDepts(prev => 
                                                             prev.includes(dept.code) 
                                                                 ? prev.filter(c => c !== dept.code)
                                                                 : [...prev, dept.code]
                                                         );
                                                     }}
                                                 />
                                             </label>
                                         ))}
                                     </div>
                                 </div>
                             )}
                         </div>

                         <div>
                            <label className="text-xs font-bold text-slate-500 uppercase mb-1 block">Ville de Départ</label>
                            <div className="relative">
                                <MapPin size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"/>
                                <input 
                                    type="text" 
                                    value={seedCommuneName} 
                                    onChange={(e) => setSeedCommuneName(e.target.value)}
                                    className={`${inputClasses} pl-9`}
                                    placeholder="Ex: Strasbourg"
                                />
                            </div>
                        </div>

                        <div className="grid grid-cols-2 gap-3">
                            <div>
                                <label className="text-xs font-bold text-slate-500 uppercase mb-1 block">Cible Hab./Zone</label>
                                <div className="flex items-center gap-2">
                                    <Users size={16} className="text-slate-400"/>
                                    <input 
                                        type="number" 
                                        value={targetPopulation} 
                                        onChange={(e) => setTargetPopulation(Number(e.target.value))}
                                        className={inputClasses} 
                                        step={500}
                                    />
                                </div>
                            </div>
                            <div>
                                <label className="text-xs font-bold text-slate-500 uppercase mb-1 block">Exclure Villes &gt;</label>
                                <input 
                                    type="number" 
                                    value={maxCommunePop} 
                                    onChange={(e) => setMaxCommunePop(Number(e.target.value))}
                                    className={inputClasses} 
                                    step={5000}
                                />
                            </div>
                        </div>
                        <p className="text-[10px] text-slate-400 mt-1">L'algorithme privilégie la proximité immédiate (Voisin le plus proche).</p>
                    </div>

                    <div className="mt-6 pt-4 border-t border-slate-100">
                         <button 
                            onClick={handleGenerateZones}
                            disabled={isGenerating}
                            className={`w-full py-4 text-white rounded-xl font-bold shadow-lg flex items-center justify-center gap-2 transition-all disabled:opacity-50 ${isGenerating ? 'bg-slate-400' : 'bg-blue-600 hover:bg-blue-700 shadow-blue-200'}`}
                        >
                            {isGenerating ? <RefreshCw className="animate-spin"/> : <Layers />}
                            {isGenerating ? generationStatus : 'Calculer le Zonage'}
                        </button>
                    </div>
                </div>

                {/* 2. Weekly Teams Manager */}
                <div className="glass-card p-0 flex flex-col flex-grow overflow-hidden">
                    <div className="p-4 border-b border-slate-100 bg-slate-50/50 flex justify-between items-center">
                        <h3 className="font-bold text-slate-800 flex items-center gap-2"><Calendar size={18}/> Équipes / Semaine</h3>
                        <div className="flex gap-1">
                             <button onClick={() => handleBulkTeams(2)} className="text-xs bg-white border border-slate-200 px-2 py-1 rounded hover:bg-blue-50 hover:text-blue-600 transition">Tout à 2</button>
                             <button onClick={() => handleBulkTeams(3)} className="text-xs bg-white border border-slate-200 px-2 py-1 rounded hover:bg-blue-50 hover:text-blue-600 transition">Tout à 3</button>
                        </div>
                    </div>
                    <div className="overflow-y-auto custom-scrollbar p-2">
                        <div className="grid grid-cols-4 gap-2">
                            {weeklyTeams.map((count, i) => (
                                <div key={i} className="bg-white border border-slate-100 p-2 rounded-lg flex flex-col items-center hover:border-blue-200 transition-colors">
                                    <span className="text-[10px] font-bold text-slate-400 uppercase">Sem {i+1}</span>
                                    <input 
                                        type="number" 
                                        min="0" max="10"
                                        className="w-full text-center font-black text-lg text-slate-800 outline-none bg-transparent"
                                        value={count}
                                        onChange={(e) => handleWeeklyTeamChange(i, parseInt(e.target.value)||0)}
                                    />
                                </div>
                            ))}
                        </div>
                    </div>
                </div>

                {/* 3. Stats */}
                {stats.zones > 0 && (
                    <div className="glass-card p-4 flex justify-between items-center text-xs font-medium text-slate-500 animate-fade-in">
                        <div className="text-center">
                            <span className="block text-lg font-black text-slate-800">{stats.zones}</span>
                            Zones
                        </div>
                        <div className="text-center">
                            <span className="block text-lg font-black text-slate-800">{stats.communes}</span>
                            Communes
                        </div>
                        <div className="text-center">
                            <span className="block text-lg font-black text-slate-800">{(stats.pop/1000).toFixed(1)}k</span>
                            Hab.
                        </div>
                    </div>
                )}
            </div>

            {/* RIGHT: MAP VISUALIZATION */}
            <div className="flex-1 glass-card p-1 relative overflow-hidden flex flex-col">
                 {/* Org Selector Tabs */}
                 <div className="absolute top-4 right-4 z-[500] flex bg-white p-1 rounded-xl shadow-md border border-slate-100">
                     {Object.entries(ORGS_CONFIG).map(([key, conf]) => (
                         <button
                            key={key}
                            onClick={() => setSelectedOrg(key as Organization)}
                            className={`px-4 py-2 rounded-lg text-xs font-bold uppercase transition-all ${selectedOrg === key ? 'text-white shadow-sm' : 'text-slate-500 hover:bg-slate-50'}`}
                            style={{ backgroundColor: selectedOrg === key ? conf.color : 'transparent' }}
                         >
                             {conf.label}
                         </button>
                     ))}
                 </div>

                 {/* View Filter (Week / All) */}
                 <div className="absolute top-4 left-4 z-[500] flex items-center gap-2 bg-white p-1 rounded-xl shadow-md border border-slate-100">
                     <div className="flex items-center gap-2 px-3">
                         <Eye size={16} className="text-slate-400"/>
                         <span className="text-xs font-bold text-slate-600 uppercase">Vue</span>
                     </div>
                     <div className="h-6 w-px bg-slate-200"></div>
                     <button 
                        onClick={() => setViewWeek('all')}
                        className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-colors ${viewWeek === 'all' ? 'bg-slate-800 text-white' : 'text-slate-500 hover:bg-slate-50'}`}
                     >
                         Tout
                     </button>
                     <div className="relative flex items-center">
                        <span className="text-xs text-slate-400 font-bold mr-2">Semaine</span>
                        <input 
                            type="number" 
                            min="1" max="52" 
                            className="w-12 text-center text-xs font-bold border border-slate-200 rounded py-1"
                            placeholder="#"
                            value={viewWeek === 'all' ? '' : viewWeek}
                            onChange={(e) => {
                                const v = parseInt(e.target.value);
                                if (!isNaN(v) && v >= 1 && v <= 52) setViewWeek(v);
                                else if (e.target.value === '') setViewWeek('all');
                            }}
                        />
                     </div>
                 </div>

                 <div id="define-areas-map" ref={mapContainerRef} className="w-full h-full rounded-xl z-0"></div>
                 
                 {/* Loading Overlay */}
                 {isGenerating && (
                     <div className="absolute inset-0 bg-white/80 backdrop-blur-sm z-[600] flex flex-col items-center justify-center">
                         <RefreshCw className="w-12 h-12 text-blue-600 animate-spin mb-4"/>
                         <span className="text-xl font-bold text-slate-800">{generationStatus}</span>
                     </div>
                 )}
            </div>
        </section>
    );
};

export default DefineAreasTab;
