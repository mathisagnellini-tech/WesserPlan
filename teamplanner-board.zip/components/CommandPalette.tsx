
import React, { useEffect, useState, useRef } from 'react';
import { Search, Zap, Layout, Activity, Eye, EyeOff, BarChart2 } from 'lucide-react';

interface CommandPaletteProps {
  isOpen: boolean;
  onClose: () => void;
  actions: {
    id: string;
    label: string;
    icon: React.ElementType;
    shortcut?: string;
    perform: () => void;
  }[];
}

export const CommandPalette: React.FC<CommandPaletteProps> = ({ isOpen, onClose, actions }) => {
  const [query, setQuery] = useState('');
  const [selectedIndex, setSelectedIndex] = useState(0);
  const inputRef = useRef<HTMLInputElement>(null);

  const filteredActions = actions.filter(action => 
    action.label.toLowerCase().includes(query.toLowerCase())
  );

  useEffect(() => {
    if (isOpen) {
      setTimeout(() => inputRef.current?.focus(), 50);
      setQuery('');
      setSelectedIndex(0);
    }
  }, [isOpen]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (!isOpen) return;

      if (e.key === 'ArrowDown') {
        e.preventDefault();
        setSelectedIndex(prev => (prev + 1) % filteredActions.length);
      } else if (e.key === 'ArrowUp') {
        e.preventDefault();
        setSelectedIndex(prev => (prev - 1 + filteredActions.length) % filteredActions.length);
      } else if (e.key === 'Enter') {
        e.preventDefault();
        if (filteredActions[selectedIndex]) {
            filteredActions[selectedIndex].perform();
            onClose();
        }
      } else if (e.key === 'Escape') {
        onClose();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, filteredActions, selectedIndex, onClose]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[9999] flex items-start justify-center pt-[15vh] bg-slate-900/50 backdrop-blur-sm animate-in fade-in duration-200" onClick={onClose}>
      <div 
        className="w-full max-w-xl bg-white rounded-xl shadow-2xl overflow-hidden border border-slate-200 flex flex-col animate-in zoom-in-95 duration-200"
        onClick={e => e.stopPropagation()}
      >
        <div className="flex items-center px-4 py-3 border-b border-slate-100">
          <Search className="w-5 h-5 text-slate-400 mr-3" />
          <input
            ref={inputRef}
            className="flex-1 bg-transparent border-none outline-none text-slate-800 placeholder:text-slate-400 text-lg font-medium"
            placeholder="Tapez une commande..."
            value={query}
            onChange={e => {
                setQuery(e.target.value); 
                setSelectedIndex(0);
            }}
          />
          <div className="text-xs font-bold text-slate-400 border border-slate-200 rounded px-1.5 py-0.5">ESC</div>
        </div>
        
        <div className="max-h-[300px] overflow-y-auto p-2">
            {filteredActions.length === 0 ? (
                <div className="px-4 py-8 text-center text-slate-500 text-sm">Aucune commande trouvée.</div>
            ) : (
                filteredActions.map((action, index) => (
                    <button
                        key={action.id}
                        onClick={() => { action.perform(); onClose(); }}
                        className={`w-full flex items-center justify-between px-3 py-3 rounded-lg text-left transition-colors ${
                            index === selectedIndex ? 'bg-blue-600 text-white' : 'text-slate-700 hover:bg-slate-100'
                        }`}
                    >
                        <div className="flex items-center gap-3">
                            <action.icon size={18} className={index === selectedIndex ? 'text-white' : 'text-slate-400'} />
                            <span className="font-medium">{action.label}</span>
                        </div>
                        {action.shortcut && (
                            <span className={`text-xs font-mono px-1.5 py-0.5 rounded ${
                                index === selectedIndex ? 'bg-blue-500 text-blue-100' : 'bg-slate-100 text-slate-400 border border-slate-200'
                            }`}>
                                {action.shortcut}
                            </span>
                        )}
                    </button>
                ))
            )}
        </div>
        
        <div className="bg-slate-50 px-4 py-2 border-t border-slate-100 flex justify-between items-center text-[10px] text-slate-400 font-medium">
            <span>Command Center v1.0</span>
            <div className="flex gap-2">
                <span>↑↓ pour naviguer</span>
                <span>↵ pour valider</span>
            </div>
        </div>
      </div>
    </div>
  );
};
